"""
    PPM Image Modifier

    Aneesh Raghavan

    11/1
"""
from math import sqrt


def decode(in_filename, out_filename):
    """
    reads file and replaces numbers whose modulo 3 = 0,1, or 2 to 0,153, or 255
    :param in_filename: (str) file that will be read
    :param out_filename: (str) file that will be written to
    :return: None
    """
    with open(in_filename, "r") as f_in,\
        open(out_filename, "w") as f_out:
        count = 1
        for line in f_in:
            if count < 4:
                f_out.write(line)
                count += 1 # To write in the 1st 3 lines

            else: # For rest of lines in the file
                l = line.split()
                for i in range(len(l)):
                    if int(l[i]) % 3 == 0:
                        l[i] = "0"
                    elif int(l[i]) % 3 == 1:
                        l[i] = "153"
                    elif int(l[i]) % 3 == 2:
                        l[i] = "255"
                str = ""
                for e in l:
                  str += e + " "
                f_out.write(str) # Writes new string values to output file


def main_part1():
    decode("files/part1.ppm","file_2.ppm")


def negate(line):
    """
    returns a string with the same number of values, but with every one negated
    :param line: (str) sequence of integers from 0 and 255 separated by whitespace
    :return: (str) string with each number subtracted from 255
    """
    l = line.split() # Turns string into list
    for i in range(len(l)):
        l[i] = 255 - int(l[i])
    s = ""
    for e in l:
        s += str(e) + " " # Turns list back into string
    return s.strip() # Gets rid of preceeding and trailing whitespace



def grey_scale(line):
    """
    returns 3 grey values for each pixel
    :param line: (str) sequence of integers from 0 and 255 separated by whitespace
    :return: (str) string with 3 grey scale values from replaced r,g,b values
    """
    l = line.split()
    res = ""
    for i in range(len(l)//3): # Iterating for each set of 3 values
        r = int(l[0+(3*int(i))])
        g = int(l[1+(3*int(i))])
        b = int(l[2+(3*int(i))])
        grey = int(sqrt(r**2+g**2+b**2)) # Grey scale formula
        if grey > 255:
            grey = 255 # 255 is max value
        res += ((str(grey) + " ") * 3)
    return res.strip() # Gets rid of preceeding and trailing whitespace


def remove_color(line, color):
    """
     sets r,g, or b value in pixel to 0
    :param line: (str) sequence of integers from 0 and 255 separated by whitespace
    :param color: (str) red, green, or blue
    :return: (str) string with corresponding color call on line value replaced to 0
    """
    l = line.split()
    res = ""
    for p in range(len(l) // 3):
        if color == "red":
            l[0 + 3*p] = "0" # Sets each red value in pixel to 0
        elif color == "blue":
            l[1 + 3*p] = "0" # Sets each blue value in pixel to 0
        elif color == "green":
            l[2 + 3*p] = "0" # Sets each green value in pixel to 0
    for e in l:
        res += str(e) + " "
    return res.strip() # Gets rid of preceeding and trailing whitespace



def main():

    # Ask the user for an input file.
    # Ask the user for an output file.

    file = input("input file name: ")
    file2 = input("output file name: ")
    print("modifications are:\n1. negate\n2. greyscale\n3. remove red\n4. remove green\n5. remove blue\n")
    num = int(input("enter the number of desired modification: "))

    # List the possible image manipulation functions and ask the user to
    # choose one of them. If they don't enter a valid choice, ask them again.

    while not 0 < num <= 5:
        print("please enter a valid number")
        num = int(input("enter the number of desired modification: "))

    with open(file, "r") as f_in, \
            open(file2, "w") as f_out:
        count = 1
        for line in f_in:
            if count < 4:
                f_out.write(line)
                count += 1 # To write in the 1st 3 lines

            else: # For rest of lines in the file
                if num == 1:
                    f_out.write(negate(line)) # negate function for each line
                elif num == 2:
                    f_out.write(grey_scale(line)) # grey scale function for each line
                elif num == 3:
                    f_out.write(remove_color(line, "red")) # remove color function for each line - red
                elif num == 4:
                    f_out.write(remove_color(line, "green")) # remove color function for each line - green
                else:
                    f_out.write(remove_color(line, "blue")) # remove color function for each line - blue
        print("done")


if __name__ == '__main__':
    #main_part1()  # comment this out after you check-in for part 1
    main()  # uncomment this after you check-in for part 1
