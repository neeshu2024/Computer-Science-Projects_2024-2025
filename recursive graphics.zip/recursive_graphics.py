"""
    CS051P Lab Assignments: Recursive Graphics

    Name: Aneesh Raghavan

    Date:   10/7/24   
"""

from turtle import *
from math import sqrt

def draw_triangle(length, color):
    """
    Draw equilateral triangle, from the current position.
    :param length: (int) side length in pixels
    :param color: (string) line color
     end up in original position and heading
    """
    # set color and drop the pen
    pencolor(color)
    pendown()

    # three sides, w/120 degree exterior angles
    # Note: this function demostrates poor style (it uses repeated code)
    forward(length)
    left(120)
    forward(length)
    left(120)
    forward(length)
    left(120)

    #we should now be at our original position/heading

# Draws shapes of different n and lengths
def draw_polygon(n, length):
    """
    draw an <n>-side polygon with each side of a length <length>
    :param n: (int) number of sides
    :param length: (int) length of each side
    :return: (int) 1 - 1 for each square
    """
    for x in range(n):
        forward(length)
        left(360/n) # 360/n indicates angles
    return 1


# Makes staircase
def stairs(x, y, length):
    """
    draw recursive stairs as specified in the handout
    :param x: (int) x position
    :param y: (int) y position
    :param length: (int) length of side
    :return: (int) n - number of squares that were drawn
    """
    up()
    goto(x,y)
    down() # Sets new location
    # Base Case
    if length <= 10:
        return 0 # Nothing

   # Recursive Case
    else:
        n = draw_polygon(4, length) # draws the new varying squares
        n += stairs(x, y + length, length/2) # 1st stairs
        n += stairs(x + length, y, length / 2) # 2nd stairs
        return n


def main_part1():
    """
    draw polygons with 3, 4, 6, 12, and 32 sides
    draw a recursive staircase that looks like the (first) one on the handout
    :return: None
    """

    # draw a dot of size 5 in the center of the screen
    dot(5)

    # fancy geometry to calculate the starting point of an equilateral triangle at the center of the screen
    # If you understand the math, great! If not, that's fine. Don't spend time worrying about it. This isn't a geometry class.
    side_len = 60
    triangle_height = sqrt(side_len**2 - (side_len/2)**2) # use Pythagorean thm
    centroid_height = triangle_height/3  # centroid is 1/3 up the height
    y_init = -1 * centroid_height
    x_init = -1 * (side_len/2)
    # draw a single triangle of size 60 in the center of the screen
    penup()
    setposition(x_init,y_init)
    pendown()
    setheading(0)
    #draw_triangle(60, "black")

    speed(0)
    draw_polygon(3,60) # Triangle
    # puts them all on same line with no overlap
    up()
    forward(100)
    down()
    draw_polygon(4, 60) # Square
    up()
    forward(100)
    down()
    draw_polygon(6, 40) # Hexagon
    up()
    forward(200)
    down()
    draw_polygon(12, 30) # 12 shaped polygon
    up()
    forward(200)
    down()
    draw_polygon(32, 10) # 32 shaped polygon

    #hide turtle and preserve the display
    hideturtle()
    print(stairs(0,0,128))
    done()

# Makes base star
def star(x,y,size):
    """
    Creates "star" or base shape
    :param x: (int) x position
    :param y: (int) y position
    :param size: (int) length of line
    :return: (int) 8 - number of sides in star
    """
    for z in range(8): # Star has 8 arms
        up()
        setpos(x,y)
        down() # Goes back to starting position after every line
        fd(size)
        right(45)
    return 8 # Number of arms


# Makes snowflake
def snowflake(x, y, size):
    """
    draw recursive snowflake as specified in the handout and return the number of arms that were drawn
    :param x: (int) x position
    :param y: (int) y position
    :param size: (int) length of line
    :return: (int) num - number of arms in snowflake
    """
    up()
    goto(x,y)
    down() # Sets new updating locations
    # Base Case
    if size < 5:
        color('red')
        dot(5) # Makes red dots at the tips
        color('black')
        return 0
    # Recursive Case
    else:
        num = star(x,y,size)
        # 4 smaller stars with updating num
        num += snowflake(x, y + size, size / 3)
        num += snowflake(x + size, y, size / 3)
        num += snowflake(x, y - size, size / 3)
        num += snowflake(x - size, y, size / 3)
        return num # Returns number of arms

def centered_circle(x, y, radius):
    penup()
    goto(x,y - radius)
    pendown()
    circle(radius)
def mystery(x, y, radius):
    z =0
    if radius <= 50:
        centered_circle(x, y, radius)
        z += 1
    else:
        z += mystery(x + radius/2, y, radius/2)
        z += mystery(x - radius/2, y, radius/2)
        z += mystery(x, y + radius/2, radius/2)
        z += mystery(x, y - radius/2, radius/2)
    return z

def main():
    """
    call snowflake for assignment
    :return: None
    """
    # x = mystery(0, 0, 200)
    # print(x)
    print(snowflake(0,0,100))
    done()


if __name__ == '__main__':
    speed(100)
    #main_part1()  # main 1
    main()  # main 2
