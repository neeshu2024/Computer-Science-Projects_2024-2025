"""
    CS051P Lab Assignments: Text Processing
    Name: Aneesh Raghavan, Erv Cruz
    Date: 10/21/24
"""

from string import whitespace
from string import *

def every_fourth_char(string):
   """
   New string constructed from every fourth letter
   :param string: (str) inputed string parameter
   :return: (str) made up of every 4th letter from original string
   """
   return string[::4] # Step of 4

def copy_parts_of_file(old_filename, new_filename):
    """
    creates a new file whose contents are the every fourth character of the old file
    :param old_filename: (str) File to be read
    :param new_filename: (str) File to write in
    :return: None
    """
    with open(old_filename , "r" , encoding="utf8") as file_1:
        with open(new_filename , "w") as file_2:
            for line in file_1:
                striped_line = line.strip() # Get rid of unecessary whitespace
                file_2.write(every_fourth_char(striped_line) + "\n") # adding new line every time


def num_characters(string):
    """
    Count and return the number of non-whitespace chars
    :param string: (str) inputed string
    :return: (int) number of non-whitespace characters in string.
    """
    counter = 0
    for char in string:
        if char not in whitespace:
            counter += 1
    return counter


def count_characters(filename):
    """
    Open and read the specified file count the number of non-whitespace chars
    :param filename: (str) inputed file
    :return: (int) total number of non-whitespace chars
    """
    with open(filename, "r", encoding="utf8") as file_1:
        counter = 0
        for line in file_1:
            for char in line: # Looping through each element in the line
                if not char in whitespace:
                  counter += 1
        return counter


def count_char(string, char):
    """
    Number of instances of a letter in a word
    :param string: (str) an inputed phrase or word
    :param char: (str) a single letter
    :return: (int) the total number of instances
    """
    counter = 0
    for c in string: # Looping through the string itself
        if c == char.lower() or c == char.upper():
            counter +=1
    return counter


def num_words(string):
    """
    Number of words in a string
    :param string: (str) inputed word or phrase that can contain whitespace
    :return: (int) number of consecutive sequences of non-whitespace characters
    """
    counter = 0
    previous = " "
    for char in string:
        if char is not previous and previous == " ": # Condition for a word
            counter += 1
        previous = char # Updates previous to the previous element
    return counter



def main():
    # Ask the user for a character to count. If the user does not enter a
    # single letter, ask them again. Continue until they enter a character.
    character = input("Enter a letter: ")
    while len(character) != 1 or character not in ascii_lowercase and character not in ascii_uppercase:
        character = input("Enter a letter: ")
        # Ask the user if they want to run in file or interactive mode by asking
        # them to enter a 1 for file mode and a 0 for interactive mode.
    user_num_1 = int(input("Enter 1 for file or 0 for interactive\n"))
    while user_num_1 != 1 and user_num_1 != 0:
        user_num_1 = int(input("Enter 1 for file or 0 for interactive\n"))
    counter = 0 # The total number of lines
    words = 0 # The total number of words
    charac = 0 # The total number of non-whitespace characters
    instances = 0 # The number of times char appears, ignoring case
    if user_num_1 == 0: # Interactive Mode
       # If the user is running in interactive mode: ask the user to enter a line of text or a - 1 if they are done.
       # Continue until the user enters a - 1.
        user_num_2 = input("Input line or -1 to stop\n")
        while user_num_2 != "-1":
            counter += 1
            words += num_words(user_num_2)
            charac += num_characters(user_num_2)
            instances += count_char(user_num_2, character)
            user_num_2 = input("Input line or -1 to stop\n")
        # Statistics
        print("\n" + "******** statistics ******** " + "\n")
        print(str(counter) + " lines")
        print(str(words) + " words")
        print(str(charac) + " non-whitespace characters")
        print(str(instances) + " " + character + "'s" + "\n")
        print("average word length is: " + str(charac/words)) # The average length of a word
        print("percentage " + character + "'s is: " + str((instances/charac)*100)) # The percentage of char
    else: # File mode
        filename = input("filename?: ")
        with open(filename, "r") as file:
            for line in file:
                counter += 1
                # Finding info line by line
                words += num_words(line)
                charac += num_characters(line)
                instances += count_char(line,character)
        # Statistics
        print("\n" + "******** statistics ******** " + "\n")
        print(str(counter) + " lines")
        print(str(words) + " words")
        print(str(charac) + " non-whitespace characters")
        print(str(instances) + " " + character + "'s" + "\n")
        print("average word length is: " + str(charac / words))  # The average length of a word
        print("percentage " + character + "'s is: " + str((instances / charac) * 100))  # The percentage of char

if __name__ == '__main__':
    main()
