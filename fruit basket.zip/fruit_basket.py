"""
    Objects

    Author: Aneesh Raghavan
    Partner: Ervin Cruz

    Date: 11/18/24
"""

class Basket:
    """
    This class simulates a fruit basket through addition and removal of fruits and their counts through a dictionary
    :attr: capacity (int): maximum number of fruit that can be held. 10 if not specified
    :attr: basket (dict): dictionary storing fruits (keys) and their counts (values)
    """

    def __init__(self, capacity = 10):
        """
        using methods, gives description of fruit basket with each fruit and its count
        :param capacity (int): maximum number of fruit that can be held. 10 if not specified
        :param basket (dict): dictionary storing fruits (keys) and their counts (values)
        """
        # Attributes
        self.capacity = capacity
        self.basket = {} # Empty dictionary

    def get_num_fruit(self):
        """
        :return: returns the number of fruit in the basket as an int
        """
        sum = 0

        for values in self.basket.values(): # Sums up values in the dictionary
            sum += values

        return sum # Returns sum


    def get_max_fruit(self):
        """
        :return: returns the capacity of the basket as an int
        """
        return self.capacity # capacity as in the instance variable

    def get_space_left(self):
        """
        :return: returns the space left in the basket as an int
        """
        return self.capacity - self.get_num_fruit()  # Space remaining in basket

    def has_fruit(self, fruit):
        """
        checks to see whether a given fruit is present in the basket
        :param fruit (str): the name of a fruit
        :return: True if basket contains fruit, False otherwise
        """
        return fruit in self.basket.keys() # Returns true if fruit is in the basket keys and flse if not



    def add_fruit(self, fruit):
        """
        if there's room in the basket, adds one of the given fruit to the basket
        :param fruit (str): the name of a fruit
        """
        if self.get_space_left() > 0:

            if self.has_fruit(fruit):
                self.basket[fruit] += 1 # Adds 1 to the value of the fruit key
            else:
                self.basket[fruit] = 1 # If not in basket, creates new fruit key with value of 1


    def remove_fruit(self, fruit):
        """
        if the given fruit is present in the basket, removes one of that fruit
        :param fruit (str): the name of a fruit
        """
        if self.has_fruit(fruit):
            self.basket[fruit] -= 1 # Subtract value of fruit key by 1 if it already exists

            if self.basket[fruit] == 0:
                self.basket.pop(fruit) # If value is 0, then that key value pair gets removed


    def __str__(self):
        """
        :return: returns a description of the basket as a str
        """
        final = ""

        for keys in self.basket.keys():
            final += keys + " (" + str(self.basket[keys]) + ") " + " " # Accumulates keys and values in the basket to final string

        return str(self.get_num_fruit())  + "/" + str(self.capacity) + ": " + final



def simulate_basket(filename):
    """
    simulates Basket class with additions and removals of fruit from a basket
    :param filename (str): file whose capacity and add or remove keywords are read in
    :return: the basket object itself from the str method
    """
    with open(filename, "r", encoding="utf-8") as file_in:
        capacity = int(file_in.readline())
        basket = Basket(capacity)
        for line in file_in.readlines():
            words = line.split()
            if words[0] == "add":
                basket.add_fruit(words[1])
            else:
                basket.remove_fruit(words[1])
    return basket


def main():
    basket = simulate_basket(input("filename?\n\t"))
    print(basket)


if __name__ == "__main__":
    main()
