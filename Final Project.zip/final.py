# Import calls
import matplotlib.pyplot as p
import csv

# Question, Plot 1: relationship between worldwide box office revenue and rotten tomato scores

def parse_scoring_boxoffice(fname):
    """
    reads superhero movie performance csv file line by line and places worldwide box office and rotten tomato rating
    values into a dictionary
    :param fname: (str) csv file containing superhero movie data
    :return: (dictionary) dictionary with key = box office worldwide values and value = corresponding rotten tomato scores
    """
    with open(fname, "r") as f:
        f.readline() # Reads in 1st line
        dct1 = {} # Create empty dictionary
        reader = csv.reader(f, delimiter=",", quotechar="\"") # Reads csv file and makes list from commas except for when they are contained in "quotation marks"

        for line in reader:
            try:
                boxoffice = int(line[4].replace("$", "").replace(",", "").replace("\"","")) # Gets rid of $," to only abstract the number
                score = int(line[16])
                dct1[boxoffice] = score # Sets int casted worldwide box office key to int casted rotten tomato score
            except ValueError: # For the last line in file containing commas
                continue

        return dct1


def boxoffice_list(dict):
    """
    takes worldwide box office-tomato score ratings dictionary and appends keys to a list
    :param dict: (dictionary) dictionary with key = worldwide box office values, value = rotten tomato scores
    :return: (list) list with appended worldwide box office values
    """
    box = [] # Empty list

    for k in dict.keys():
        box.append(k) # Appends worldwide box office score keys into list

    return box


def ratings_list(dict):
    """
    takes worldwide box office-tomato score ratings dictionary and appends values to a list
    :param dict: (dictionary) dictionary with key = worldwide box office values, value = rotten tomato scores
    :return: (list) list with appended rotten tomato score values
    """
    ratings = [] # Empty list

    for k in dict.keys():
        ratings.append(dict[k]) # Appends rotten tomato score values into list

    return ratings


def plot_score_boxoffice(ratings, box):
    """
    plots the data from 2 lists with ratings on x-axis and box office on y-axis as scatter plot
    :param ratings: (list) list containing worldwide box office values
    :param box: (list) list containing corresponding rotten tomato score values
    :return: None
    """
    p.xlabel("Rotten Tomato Score")  # X axis label
    p.ylabel("Box Office Worldwide ($ in billions)")  # Y axis label
    p.title("Rotten Tomato Score vs Box Office Worldwide for Superhero Movies")  # Title of plot

    p.scatter(ratings, box) # Creates scatter plot
    p.show()


# Question, Plot 2: relationship between years and average budget of superhero movies in that year

def parse_year_budget(fname):
    """
    reads superhero movie performance csv file line by line and places year and average yearly budget into a dictionary
    :param fname: (str) csv file containing superhero movie data
    :return: (dictionary) dictionary with key = year, value = average budget per year through call to average function
    """
    with open(fname, "r") as f:
        f.readline() # Reads in 1st line
        dct2 = {} # Create empty dictionary
        inter1 = {} # Creates intermediate dictionary
        reader = csv.reader(f, delimiter=",", quotechar="\"") # Reads csv file and makes list from commas except for when they are contained in "quotation marks"

        for line in reader:
            try:
                budget = int(line[5].replace("$", "").replace(",", "").replace("\"", ""))
                year = int(line[18])
                if year in dct2.keys():
                    dct2[year] += budget # Accumulates total budget for repeating years
                    inter1[year] += 1 # Accumulates count of year
                else:
                    dct2[year] = budget # Sets budget value to year key if a unique year
                    inter1[year] = 1 # Sets count to 1 if a unique year

            except ValueError: # For the last line in file containing commas
                continue

        return average(dct2,inter1) # Returns call to average function


def average(dct, inter):
    """
    modifies year-budget dictionary values to average yearly budget and superhero character-worldwide box office
    dictionary values to average worldwide box office for each character
    :param dct: (dictionary) dictionary containing key = year or superhero character and value = total budget in that
    year or total worldwide box office per character
    :param inter: (dictionary) dictionary with key = year and value = count of number of times that year appeared or
    key = superhero character and value = count of number of times character appeared
    :return: (dictionary) dictionary containing key = year and value = average yearly budget or key = superhero
    character and value = average worldwide box office for that character
    """
    average = {} # Empty dictionary

    for key in dct:
        average[key] = (dct[key] / inter[key]) # Sets year key to average budget of that year

    return average


def year_list(dict):
    """
    takes in year-budget dictionary and appends keys to a list
    :param dict: (dictionary) dictionary with key = year and value = average budget
    :return: (list) list with appended year values
    """
    year = [] # Empty list

    for k in dict.keys():
        year.append(k) # Appends year keys to list

    return year


def budget_list(dict):
    """
    takes in year-budget dictionary and appends values to a list
    :param dict: (dictionary) dictionary with key = year and value = average yearly budget
    :return: (list) list with appended average yearly budget values
    """
    budget = [] # Empty list

    for k in dict.keys():
        budget.append(dict[k]) # Appends average yearly budget values to list

    return budget


def plot_budget_year(budget, year):
    """
    plots the data from 2 lists with year on x-axis and average budget on y-axis as a scatter plot
    :param year: (list) list containing years
    :param budget: (list) list containing average yearly budgets
    :return: None
    """
    p.xlabel("Year")  # X axis label
    p.ylabel("Average Budget per Year ($ in hundred millions)")  # Y axis label
    p.title("Average Budget vs Year for Superhero Movies")  # Title of plot

    p.scatter(year, budget) # Creates scatter plot
    p.show()


# Question, Plot 3: bar chart showing top 5 most bankable superhero characters according to highest average worldwide box office revenue

def parse_character_bankable(fname):
    """
    reads superhero movie performance csv file line by line and places character and average worldwide box office for
    each character into a dictionary
    :param fname: (str) csv file containing superhero movie data
    :return: (dictionary) dictionary with key = superhero/superhero character group, value = average worldwide budget per
    character through call to average function
    """
    with open(fname, "r") as f:
        f.readline() # Reads in 1st line
        dct3 = {} # Create empty dictionary
        inter2 = {} # Creates intermediate dictionary
        reader = csv.reader(f, delimiter=",", quotechar="\"") # Reads csv file and makes list from commas except for when they are contained in "quotation marks"

        for line in reader:
            try:
                boxoffice2 = int(line[4].replace("$", "").replace(",", "").replace("\"", ""))
                character = line[13]
                if character in dct3.keys():
                    dct3[character] += boxoffice2 # Accumulates total worldwide box office for repeating characters
                    inter2[character] += 1 # Accumulates count of character appearances
                else:
                    dct3[character] = boxoffice2 # Sets box office value to year key if a unique year
                    inter2[character] = 1 # Sets count to 1 if a unique year

            except ValueError: # For the last line in file containing commas
                continue

        return average(dct3,inter2) # Returns call to average function


def top_5_characters(dct):
    """
    takes top 5 bankable superheroes and their average worldwide box office values from the character-average worldwide
    box office dictionary
    :param dct: (dictionary) dictionary with key = superhero character/character group and value = average worldwide box
    office per character
    :return: (dictionary) dictionary with key = characters of top 5 max values and value = top 5 max average worldwide
    box office values
    """
    dct_final = {} # Creates empty dictionary

    for i in range(5): # Getting top 5
        max_val = 0
        max_key = ""

        for k,v in dct.items(): # Looping through items within the dictionary
            if v > max_val:
                max_val = v # Gets max value
                max_key = k # Gets key of max value
        dct_final[max_key] = max_val
        dct.pop(max_key) # Pops key to restart to find next max

    return dct_final


def character_list(dict):
    """
    takes top 5 dictionary and appends keys to a list
    :param dict: (dictionary) dictionary with key = top 5 superheroes with greatest average worldwide box office values
    and value = top 5 greatest average worldwide box office values
    :return: (list) list of appended superhero characters/character group with top 5 average worldwide box office per
    character values
    """
    character = [] # Creates empty list

    for k in dict.keys():
        character.append(k) # Appends superhero character keys into list

    return character


def boxoffice_list_2(dict):
    """
    takes top 5 dictionary and appends values to a list
    :param dict: (dictionary) dictionary with key = top 5 superheroes with greatest average worldwide box office values
    and value = top 5 greatest average worldwide box office values
    :return: (list) list of appended top 5 average worldwide box office per character values
    """
    box = [] # Creates empty list

    for k in dict.keys():
        box.append(dict[k]) # Appends average box office values as opposed to keys into list

    return box


def plot_boxoffice_char(boxoffice, character):
    """
    plots the data from 2 lists with top 5 bankable superhero character on x-axis and  their average worldwide box
    office values on y-axis as a bar chart
    :param character: (list) list containing top 5 bankable superhero character/character groups
    :param boxoffice: (list) list containing top 5 average worldwide box office values
    :return: None
    """
    p.ylabel("Box Office Worldwide ($ in billions)")  # Y axis label
    p.title("How Bankable is each Superhero Group")  # Title of plot
    barw = 0.3 # Bar chart width

    p.bar(character, boxoffice, barw) # Creates bar chart
    p.show()



def main():
    """
    Based off superhero movie performance csv file, calls parse, list, and top 5 functions for data processing, analysis, and
    categorization into x and y variables and plot functions for scatter plot and bar chart visualization to answer my 3 questions
    :param:
    :return:
    """
    plot_score_boxoffice(ratings_list(parse_scoring_boxoffice("dc_marvel_movie_performance (1).csv")),boxoffice_list(parse_scoring_boxoffice("dc_marvel_movie_performance (1).csv"))) # Question, Plot 1

    plot_budget_year(budget_list(parse_year_budget("dc_marvel_movie_performance (1).csv")),year_list(parse_year_budget("dc_marvel_movie_performance (1).csv"))) # Question, Plot 2

    plot_boxoffice_char(boxoffice_list_2(top_5_characters(parse_character_bankable("dc_marvel_movie_performance (1).csv"))),character_list(top_5_characters(parse_character_bankable("dc_marvel_movie_performance (1).csv")))) # Question, Plot 3


if __name__ == '__main__':
    main()

