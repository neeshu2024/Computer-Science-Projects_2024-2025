"""
    CS051P Lab Assignments: Credit Cards, Part 1

    Name: Aneesh Raghavan

    Date:   9/30/24
"""

# Finds last digit of a number
def last_digit(num):
    """
    Computes the last digit of the num
    :param num: (int) a positive integer
    :return: (int) the last digit of num
    """
    return num % 10 # Modulo returns the last digit

# Shifts decimal by 1 from right to left
def decimal_right_shift(num):
    """
    Right shifts num by one digit
    :param num: (int) a positive intger
    :return: (int) num right shifted by one digit
    """
    return num // 10 # Truncated division shifts number

# Use 2 functions above to find sum a 3-digit number
def sum_digits(num3):
    """
    Sums the digits of a three-digit number
    :param num3: (int) a positive, three-digit number
    :return: (int) the sum of the digits of num3
    """
    sum = 0
    while num3 > 0:
        sum += last_digit(num3)
        num3 = decimal_right_shift(num3)
    return sum

def main():
    """
    prints values of the 3 functions above
    checks if inputed number is 3 digits and prints out that number and its sum
    """
    print(last_digit(23))
    print(decimal_right_shift(123))
    print(sum_digits(267))
    number = input("Please enter a 3-digit positive integer: ")
    count = 0 # Counter variable
    for x in number:
        decimal_right_shift(int(number))
        count+=1
    while count != 3: # While it is not a 3-digit number
        number = input("Please enter a 3-digit positive integer: ")
    print("The sum of the digits of " + number + " is " + str(sum_digits(int(number))))


if __name__ == "__main__":
    main()
