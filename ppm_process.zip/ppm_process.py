"""
    CS051P Lab Assignments: PPM Processing

    Name: Aneesh Raghavan, Erv Cruz

    Date:   11/4/2024

    The goal of this assignment is to give you practice working with nested lists
    by writing a program that manipulates the entire image with multiple lines.
"""

# Creates row and col dependent list of lists
def process(lines, rows, cols):
    """
    store body of an image as a nested list according to row and column input
    :param lines: (list) list of strings consisting of the image body
    :param rows:  (int) representing the number of rows
    :param cols: (int) representing the number of columns
    :return: (list) list of lists with new row and col length
    """
    lst = []
    row = []

    for line in lines:
        for num in line.split():
            row.append(int(num)) # add num to row
            if len(row)  == 3*cols: # check if row size is 3*col
                lst.append(row) # add row to list
                row = [] # reset row to be []

    return lst



# Reading processed image
def read_ppm(filename):
    """
    opens file, reads it, calls process with the correct parameters, and returns list of lists
    :param filename: (str) ile name of a PPM image
    :return: (list) list of lists returned by process.
    """
    with open (filename, "r") as new_file:
        new_file.readline()
        split_file = new_file.readline().split() # Splits only the second line
        row = int(split_file[1]) # 2nd number or the height
        col = int(split_file[0]) # 1st number or the width
        new_file.readline()

        return process(new_file.readlines(), row, col ) # Call to process function

# Writing image to output file
def write_ppm(image, filename):
    """
    interprets list of lists as an image and writes out valid ppm file to output file
    :param image: (list) list of lists of integer numbers
    :param filename: (str) output file with outputed image plus header of 1st 3 lines
    :return: None
    """
    with open(filename, "w") as f:
        # Writes in 1st 3 lines of header
        f.write("P3\n")
        f.write(str((len(image[0])//3)) + " " + str(len(image)) + "\n") # Col and row values
        f.write("255\n")

        for list in image:
            for num in list:
                f.write(str(num) + " ")
            f.write("\n") # include new line after every row

# Re-scaling image
def scale(image, row_scale, col_scale):
    """
    output should take every row_scaleth and col_scaleth item in image
    :param image: (list) list of lists of integer numbers
    :param row_scale: (int) row scaling factor
    :param col_scale: (int) column scaling factor
    :return: (list) re-scaled image based on row and col scaling factors
    """
    row_lst = []
    final = []

    for row in range(len(image)):
        if row % row_scale == 0: # Condition for valid row
            row_lst.append(image[row])
    for row in row_lst:
        mini = []
        for col in range(0,len(row),col_scale*3):
            mini.extend(row[col:col+3]) # Get 3 values or a pixel
        final.append(mini) # Append the valid parts or columns of valid row to final list

    return final


def main():
    """
    The program will read from the input file and create a new file with the specified name that contains a copy of the
    input file scaled down by the inputed specified factors.
    :param:
    :return:
    """
    # Ask the user for an input file name.
    # Ask the user for an output file name.
    file_in = input("Enter input file name: ")
    file_out = input("Enter output file name: ")

    # Ask the user for a height scaling factor.
    # Ask the user for a width scaling factor.
    # (Note that you should enforce both scaling factors must be positive integers)
    height = int(input("Enter height scaling factor: "))
    while height <= 0:
        height = int(input("Enter height scaling factor: "))
    width = int(input("Enter width scaling factor: "))
    while width <= 0:
        width = int(input("Enter width scaling factor: "))

    image = scale(read_ppm(file_in), height, width)
    write_ppm(image,file_out)


if __name__ == '__main__':
    main()
