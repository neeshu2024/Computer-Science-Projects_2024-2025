"""
    CS051P Lab Assignments: Stock v.s. Rain

    Author: Aneesh Raghavan

    Date: 11/15/24

    The goal of this assignment is to familiarize you with data analysis
    and visualization. You'll practice handling files in csv format,
    create and manipulate Python dictionaries, and do some basic plotting
    using the matplotlib package.
"""
import matplotlib.pyplot as p
import numpy as np
from random import shuffle

# Reads file into rain dictionary
def parse_rainfall(fname):
    """
    reads file and returns dictionary with dates and total precipitation for that date
    :param fname: (string) file that contains complete weather dataset and is name of the file
    :return: (dictionary) dictionary with dates and precipitation data for Seattle
    """
    with open (fname,"r") as f:
        dct = {} # Empty dictionary
        f.readline() # Reads in header first line
        for line in f:
            date = ""
            lst = line.split(",") # Splits line into list by commas
            for c in lst[0]:
                if c != "\"": # Making sure extra ' are not added
                    date += c
            if lst[1] != '\"NA\"':
                dct[date] = float(lst[1]) # Setting a value to a key

        return dct

# Creates updated date format
def date(date):
    """
    translates dates with '/' into YYYY-MM-DD format
    :param date: (string) 1st element in lst, which is taken from reading the stock file
    :return: (string) new date with '-' and 0 in from of days and months that are a single digit
    """
    str = ""
    new = date.split("/") # Creates new list by /
    year = "20" + new[2] # Adding a 20 in from of last 2 year digits
    month = new[1]

    if len(month) < 2:
        month = "0" + new[1] # If month is a single digit
    day = new[0]
    if len(day) < 2:
        day = "0" + new[0] # If day is a single digit
    str += year + "-" + day + "-" + month

    return str # Returns updated string with right date format

# Reads file into stock dictionary
def parse_stock(fname, sym):
    """
    reads file and returns dictiorany of an updated date with the difference between the closing and opening price of sym stock
    :param fname: (string) string that is the name of a file with stock information
    :param sym: (string) string that is a stock symbol.
    :return: (dictionary) dates with change in price, defined as Close minus Open for the sym stock symbol
    """
    with open (fname,"r") as f:
        dct = {}
        f.readline() # Reads in header

        for lines in f:
            lst = lines.split(",") # Splits line into list by commas
            str = ""
            for char in lst[len(lst)-1]:
                if char == "\n": # As soon as it reads \n, loop breaks
                    break
                str += char
            if str != sym:
                continue # Continues into next loop iteration if last element in list is not equal to stock symbol
            new_date = date(lst[0])  # Calls date function on 1st element of list
            if lst[4] != '' and lst[1] != '':
                dct[new_date] = round((float(lst[4]) - float(lst[1])),2) # Sets value of key to rounded float difference between Close - Open

        return dct

# Creates list of list of 2
def correlate_data(stock_dict, rain_dict):
    """
    combines two dictionaries into a single list containing precisely the data to be plotted.
    :param stock_dict: (dictionary) dictionary mapping date strings to floats representing daily changes in stock prices
    :param rain_dict: (dictionary) mapping date strings to floats representing rainfall daily totals
    :return: (list) returns a list of size 2 lists, which represents a [stock_price_change, rainfall] pair.
    """
    final = []
    for key in stock_dict.keys(): # Iterating through keyes in stock dictionary
        lst = [] # Resets list to 0
        for date in rain_dict.keys(): # Iterating through keyes in rain dictionary
            if key == date:
                lst.append(stock_dict[key])
                lst.append(rain_dict[date]) # Creates list of 2
        if len(lst) == 2:
            final.append(lst) # Appends list to final

    return final


# Creates scatter plot
def scatter_plot(data, format, name, done):
    """
    plots the data in data, plotting hypothesized cause (rain) on x-axis and the hypothesized effect (stock price change) on y-axis. However, plot and the legend are displayed if done is True.
    :param data: (list) list where each entry is a list of size 2
    :param format: (string) matplotlib format string
    :param name: (string) represents the stock whose data is being passed in
    :param done: (boolean) boolean that is True if and only if this is the last plot.
    :return: None
    """
    stock = []
    rain = []

    for r in range(len(data)):
        stock.append(data[r][0]) # Appends 1st element in data to stock
        rain.append(data[r][1]) # Appends 2st element in data to rain

    p.xlabel("Rainfall") # X axis label
    p.ylabel("Price Change") # Y axis label
    p.title("Rainfall vs Price Change") # Title of plot
    p.plot(rain,stock,format,label=name)

    if done:
        p.legend() # If done is true, legend and graph appears
        p.show()

def main():
    """
    Based off user rain and stock csv files and stock symbols inputs, calls parse_rainfall and parse_stock for data processing and correlated_data and scatter_plot
    for data analysis and visualization
    :param:
    :return:
    """
    # Ask the user for an input of a rainfall data file
    # Ask the user for an input of a stock data file
    # Ask the user for two stock symbols
    rain = input("Enter the name of a rainfall data file: ")
    stock = input("Enter the name of a stock data file: ")
    symbol1 = input("Enter a first stock symbol (e.g. MSFT or AMZN): ")
    symbol2 = input("Enter a second stock symbol (not head-quartered in Seattle): ")
    name = "cs51"
    name.isdigit()

    # Creates graphs
    scatter_plot(correlate_data(parse_stock(stock,symbol1),parse_rainfall(rain)),'b.',symbol1,False) # First done is set to False
    scatter_plot(correlate_data(parse_stock(stock,symbol2),parse_rainfall(rain)),'r+', symbol2, True)



if __name__ == '__main__':
    main()
